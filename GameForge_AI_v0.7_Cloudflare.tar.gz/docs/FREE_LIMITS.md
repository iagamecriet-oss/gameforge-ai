# Limites gratuitos

Workers Free atualmente permite 100.000 requisições por dia. Workers AI inclui uma franquia de 10.000 Neurons por dia sem cobrança; ao exceder a franquia no Free, novas operações falham em vez de continuar automaticamente como uso pago.

O GameForge deve manter esse comportamento: sem upgrade automático, sem chave de pagamento no frontend e sem fallback para modelos pagos.
