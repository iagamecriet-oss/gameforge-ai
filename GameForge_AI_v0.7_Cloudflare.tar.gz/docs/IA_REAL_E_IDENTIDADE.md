# IA real + identidade visual

A versão 0.6 adiciona:

- `/api/test-ai`: prova que o binding `AI` de texto está respondendo.
- `/api/art`: gera assets com FLUX.1 schnell.
- `/api/art/lock`: usa Llama 3.2 11B Vision para extrair um lock textual da identidade de personagem/inimigo.
- `GAME_SPEC.json` guarda o `character_lock` e restrições.
- Os prompts seguintes reutilizam o lock para reduzir mudanças visuais.

A consistência ainda é probabilística: o lock é um mecanismo de orientação textual, não uma garantia de identidade pixel a pixel.
