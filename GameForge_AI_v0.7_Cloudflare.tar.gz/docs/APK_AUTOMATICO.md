# APK automático — GameForge AI 0.6

## 1. APK do próprio GameForge AI

O workflow `.github/workflows/build-gameforge-apk.yml` compila o wrapper Android sem Android Studio. O app abre a URL HTTPS do Worker Cloudflare e permite trocar a URL dentro do próprio aplicativo.

No GitHub: **Actions → Build GameForge AI APK → Run workflow**. O resultado aparece em **Artifacts** como `gameforge-ai-debug-apk`.

A compilação usa GitHub Actions, Android SDK, Java 17 e Gradle em nuvem. O APK é de debug e pode ser instalado para testes. Um release assinado para distribuição exige um keystore do proprietário.

## 2. APK de um jogo criado pelo GameForge

Salve o ZIP exportado pelo GameForge como `gameforge-input.zip` na raiz do repositório e execute **Actions → Build generated Godot game APK**.

O workflow extrai o projeto, verifica `project.godot` e `export_presets.cfg`, importa/exporta com Godot 4.7.2 e publica o APK como artifact. Godot requer um preset Android para exportação por linha de comando e o APK é um formato de saída oficial.

Não coloque chaves de assinatura dentro do repositório. Para Play Store, use AAB/release com segredos do GitHub e keystore próprio.
