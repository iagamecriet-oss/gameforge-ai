# GameForge AI 0.7 — mecânicas modulares

## Platformer

O gerador agora produz uma implementação específica com:

- movimento lateral;
- gravidade e pulo;
- chão que cobre a largura do nível;
- plataformas;
- inimigos de patrulha;
- moedas/coletáveis;
- pontuação;
- objetivo de final de fase;
- vitória.

## Shooter

O gerador agora produz uma implementação diferente do platformer com:

- movimento 2D;
- tiro;
- projéteis reais;
- colisão de projéteis;
- dano nos inimigos;
- vida dos inimigos;
- inimigos perseguindo o jogador;
- pontuação por inimigo derrotado;
- vitória ao derrotar todos os inimigos;
- controles touch específicos para movimento e tiro.

## Validação

`npm run test:generated` gera os dois tipos em memória e verifica se as mecânicas obrigatórias estão presentes nos arquivos Godot.

O endpoint `POST /api/validate` executa o mesmo Validator antes da exportação.
