# Arquitetura — GameForge AI 0.6

```text
Android / PWA / APK wrapper
  | localStorage: projetos, revisões, histórico e identidade
  | HTTPS + AbortController
  v
Cloudflare Worker
  |-- /api/generate --> Workers AI --> GAME_SPEC normalizada
  |-- /api/improve  --> Workers AI --> nova revisão
  |-- /api/art      --> FLUX.1 schnell --> asset com seed
  |-- /api/art/lock --> Llama 3.2 11B Vision --> lock textual de identidade
  |-- /api/test-ai  --> prova do binding AI
  |-- /api/export   --> gerador Godot + ZIP STORE + export_presets.cfg
  |-- /api/health   --> diagnóstico
  +--> ASSETS       --> HTML/CSS/JS/PWA

GitHub Actions
  |-- Build GameForge AI APK       --> wrapper Android instalável
  +-- Build generated Godot game APK --> APK do jogo criado
```

O estado editável permanece no aparelho nesta etapa para evitar dependência de banco pago. O Worker não recebe chaves privadas do frontend.

A identidade visual é armazenada em `GAME_SPEC.art.identity`. O `character_lock` é produzido opcionalmente por um modelo de visão depois que uma folha de sprites é gerada. Esse lock textual é reutilizado pelos prompts seguintes; ele melhora a coerência, mas não garante identidade pixel a pixel.
