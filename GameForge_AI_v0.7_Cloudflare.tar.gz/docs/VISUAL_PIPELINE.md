# GameForge AI Visual Pipeline v0.7

A pipeline visual agora tem dois níveis de consistência.

## Nível 1 — Seed e contrato

A `GAME_SPEC` mantém `visual_seed`, estilo, paleta, humor, prompt-base e regras de identidade. Cada asset deriva um seed determinístico do projeto + tipo de asset.

## Nível 2 — Lock visual por visão

Depois de gerar `player_sheet` ou `enemy_sheet`, o usuário pode executar `Fixar identidade`. O Worker envia a imagem ao modelo `@cf/meta/llama-3.2-11b-vision-instruct`, que produz descrição, cores, proporções, silhueta, materiais e restrições. Essas informações são gravadas em `character_lock` e reutilizadas nos próximos prompts.

O modelo de visão requer a aceitação da licença/uso da Meta na primeira utilização segundo a documentação atual da Cloudflare.

## Assets

- `player_sheet`: 4 quadros horizontais, idle / walk A / walk B / jump.
- `enemy_sheet`: 4 quadros horizontais, idle / move A / move B / hurt.
- `background`: fundo amplo 2D.
- `texture`: textura de plataforma/material.

Godot usa `Sprite2D hframes=4` para tratar as folhas como atlas e um shader chroma-key para remover o fundo magenta das folhas animadas.

A consistência continua probabilística porque FLUX.1 schnell é texto-para-imagem. Um lock textual é uma camada de controle, não uma prova matemática de identidade.
