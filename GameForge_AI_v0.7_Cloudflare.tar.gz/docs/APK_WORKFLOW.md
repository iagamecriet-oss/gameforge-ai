# APK em nuvem — GameForge AI 0.6

## APK do próprio GameForge

O workflow `.github/workflows/build-gameforge-apk.yml` usa Java 17 + Gradle + Android SDK para compilar o wrapper Android. O wrapper abre a URL HTTPS do Worker e permite configurá-la dentro do próprio aplicativo.

No GitHub: `Actions` → `Build GameForge AI APK` → `Run workflow`. O resultado fica em `Artifacts` como `gameforge-ai-debug-apk`.

O build é debug para instalação/teste. Um APK release para distribuição requer assinatura própria; segredos de assinatura nunca devem ser colocados no repositório.

## APK do jogo criado

1. Exporte o projeto pelo GameForge.
2. Renomeie o ZIP para `gameforge-input.zip`.
3. Envie esse único arquivo para a raiz do repositório.
4. Execute `Actions` → `Build generated Godot game APK`.
5. Baixe o artifact `gameforge-generated-game-apk`.

O workflow usa Godot 4.7.2, procura `project.godot` e `export_presets.cfg` dentro do ZIP, instala o SDK Android necessário e usa a action `firebelley/godot-export` para exportar o preset `Android`. Os binários e templates são baixados da release oficial no GitHub, que é a origem válida para esta versão.

Os projetos gerados habilitam a importação ETC2/ASTC exigida pelo exportador Android e incluem um ícone padrão para evitar falha ou aviso de configuração no export.

Segundo a documentação do Godot, a exportação por linha de comando depende de um preset e o APK é uma saída oficial do exportador. O preset gerado pelo GameForge inclui ARM64 para o build de teste.
