# GameForge AI 0.7 — IA real e APK automático

## 1. Cloudflare Workers AI

O `wrangler.jsonc` já declara:

```json
"ai": { "binding": "AI" }
```

Publique o Worker pela primeira vez com uma conta Cloudflare que tenha Workers AI disponível. Depois abra a URL pública e use **Testar IA** no GameForge.

O teste deve retornar `connected=true`. Se retornar 503, a versão publicada não possui o binding AI disponível ou a cota/modelo falhou.

O planejador usa `@cf/meta/llama-3.1-8b-instruct-fp8` com JSON Mode. A geração visual usa FLUX.1 schnell e o lock usa Llama Vision.

## 2. GitHub para APK

O Worker precisa de duas variáveis/secrets:

- `GITHUB_TOKEN`: token com permissão para escrever conteúdo no repositório e disparar Actions.
- `GITHUB_REPO`: `usuario/repositorio`.

O fluxo é:

1. GameForge cria o projeto Godot.
2. `/api/validate` valida as mecânicas.
3. `/api/build` cria o ZIP.
4. O Worker envia o ZIP para `gameforge-builds/` no GitHub.
5. O Worker dispara `build-generated-game-apk.yml`.
6. GitHub Actions baixa o ZIP.
7. Godot 4.7.2 exporta Android.
8. O APK fica nos artefatos da execução.

O workflow usa os builds oficiais do Godot no GitHub, não TuxFamily.

## 3. Permissões recomendadas do token

Para um token fine-grained, conceda somente ao repositório do GameForge:

- Contents: Read and write
- Actions: Read and write

Nunca coloque esse token no frontend, no APK ou no repositório.

## 4. Limite importante

O código está preparado para IA real e para disparar o APK automaticamente, mas a primeira conexão real precisa ser feita na conta Cloudflare/GitHub do proprietário. Este pacote não contém nem deve conter tokens privados.
