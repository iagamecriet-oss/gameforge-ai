# Fluxo Android sem computador

1. GitHub no navegador do Android: crie um repositório para o GameForge.
2. Envie os arquivos deste pacote.
3. Cloudflare: publique o Worker e ative o binding `AI`.
4. Abra `/api/health` para verificar se o Worker responde.
5. No GameForge, use `Testar IA` para confirmar a IA real.
6. Gere um jogo e, no laboratório visual, gere o player e use `Fixar identidade`.
7. Exporte o ZIP Godot.
8. Envie o ZIP para o repositório com o nome `gameforge-input.zip`.
9. Rode `Build generated Godot game APK`.
10. Baixe o artifact no Android e instale o APK debug.
