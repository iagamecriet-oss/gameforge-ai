# Relatório de testes — GameForge AI 0.6

A auditoria completa está em [`RELATORIO_AUDITORIA_PROFUNDO.md`](../RELATORIO_AUDITORIA_PROFUNDO.md).

## Resultado final

| Verificação | Resultado |
|---|---|
| `npm run check` | OK |
| JSON de configuração, manifest e rotas | OK |
| Rotas Worker com IA simulada | OK |
| Validação de Base64 inválido | HTTP 400, OK |
| Validação de asset desconhecido | HTTP 400, OK |
| Importação dos projetos Godot platformer/shooter | OK |
| APK wrapper Android | BUILD SUCCESSFUL |
| APK platformer gerado | Exportado, assinado e verificado |
| APK shooter gerado | Exportado, assinado e verificado |
| IA Cloudflare real | Não validada: binding ausente |
| Instalação em dispositivo Android | Não executada: nenhum ADB conectado |

## APKs produzidos

- `artifacts/gameforge-ai-debug.apk`
  - SHA-256: `0b8659dc98f0541df6fd9fd2d89cf89613f60de5c2396387a10db4c3739c1eaa`
- `artifacts/platformer-medieval.apk`
  - SHA-256: `4b3c7bd50bec4e6cdac71c575f0b0e4f378aeb3496e4d1eb321b32a84e62a764`
- `artifacts/shooter-espacial.apk`
  - SHA-256: `fb65955b7c3f35f73ffd66a66b8c57638d57b85c8f67019ba42b0196cc9c9a5a`

Todos são builds debug. Não há APK release/AAB assinado pelo proprietário.

## IA real

O teste executado sem binding foi:

```text
POST /api/test-ai → HTTP 503
Workers AI não está conectado.
```

A geração local caiu corretamente para `source=fallback`. Para validar IA real, é necessário publicar o Worker com binding `AI` e chamar as rotas contra a URL pública.
