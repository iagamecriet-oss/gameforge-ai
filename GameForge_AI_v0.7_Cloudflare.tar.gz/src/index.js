const MODEL = '@cf/meta/llama-3.1-8b-instruct-fp8';
const IMAGE_MODEL = '@cf/black-forest-labs/flux-1-schnell';
const VISION_MODEL = '@cf/meta/llama-3.2-11b-vision-instruct';
const VISUAL_VERSION = '0.7.0';
const ART_KINDS = ['player_sheet','enemy_sheet','background','texture'];
const MAX_PROMPT = 1800;
const MAX_INSTRUCTION = 1000;
const MAX_ART_PROMPT = 2048;
const MAX_ASSET_BYTES = 8 * 1024 * 1024;
const MAX_TOTAL_ASSET_BYTES = 16 * 1024 * 1024;
const GITHUB_API = 'https://api.github.com';

const defaultSpec = (prompt, genre = '2D', style = 'Pixel Art') => {
  const p = String(prompt || '').toLowerCase();
  const platformer = /plataforma|platform|pular|salto|parkour/.test(p);
  const shooter = /tiro|atirar|shooter|arma|space shooter/.test(p);
  return {
    name: slug(String(prompt || 'Meu jogo')).slice(0, 28) || 'Meu jogo',
    description: String(prompt || 'Protótipo 2D mobile'),
    genre,
    style,
    game_type: platformer ? 'platformer' : shooter ? 'shooter' : 'prototype_2d',
    goal: platformer ? 'Chegue ao portal final sem perder toda a vida.' : shooter ? 'Derrote todos os inimigos e sobreviva.' : 'Alcance o objetivo da fase.',
    features: {
      mobile_touch: true,
      camera_follow: true,
      hud: true,
      score: true,
      combat: shooter,
      collectibles: platformer,
      victory: true
    },
    player: { speed: 260, jump_velocity: -480, gravity: 1200, health: 100, fire_rate: 3.5, projectile_speed: 760 },
    enemy: { count: 3, speed: 70, damage: 10, patrol_distance: 180, health: 2 },
    level: {
      width: 3200,
      height: 720,
      platforms: [
        { x: 550, y: 500 }, { x: 950, y: 420 }, { x: 1410, y: 520 },
        { x: 1880, y: 390 }, { x: 2370, y: 480 }
      ]
    },
    theme: {
      background: '#16253a', platform: '#4f7191', player: '#5eead4', enemy: '#fb7185'
    },
    art: {
      palette: 'contrastante e legível',
      mood: 'aventura',
      visual_identity: `identidade coesa de ${style} para ${slug(String(prompt || 'Meu jogo'))}`,
      visual_seed: 13371337,
      identity: {
        name: 'protagonista',
        visual_description: 'silhueta clara, proporções consistentes e leitura imediata',
        outfit_colors: 'definidos pela paleta do projeto',
        proportions: 'corpo estilizado de jogo 2D',
        art_style: style,
        seed: 13371337,
        base_prompt: '',
        references: [],
        character_lock: '',
        constraints: []
      },
      assets: ART_KINDS
    }
  };
};

function slug(value) {
  return String(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 28) || 'meu_jogo';
}

function cleanJson(text) {
  if (text && typeof text === 'object') {
    if (text.response && typeof text.response === 'string') text = text.response;
    else return text;
  }
  const s = String(text || '').trim();
  const fenced = s.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  const candidate = fenced ? fenced[1] : s;
  const first = candidate.indexOf('{');
  const last = candidate.lastIndexOf('}');
  if (first >= 0 && last > first) return JSON.parse(candidate.slice(first, last + 1));
  return JSON.parse(candidate);
}

function hex(value, fallback) {
  const v = String(value || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(v) ? v : fallback;
}

function normalizeSpec(raw, prompt, genre, style) {
  const base = defaultSpec(prompt, genre, style);
  const r = raw && typeof raw === 'object' ? raw : {};
  const platforms = Array.isArray(r.level?.platforms) ? r.level.platforms : base.level.platforms;
  return {
    ...base,
    ...r,
    name: slug(r.name || base.name),
    description: String(r.description || base.description).slice(0, 240),
    genre: String(r.genre || genre || base.genre).slice(0, 40),
    style: String(r.style || style || base.style).slice(0, 40),
    game_type: ['platformer', 'shooter', 'prototype_2d'].includes(r.game_type) ? r.game_type : base.game_type,
    goal: String(r.goal || base.goal).slice(0, 200),
    features: { ...base.features, ...(r.features || {}), mobile_touch: true, camera_follow: true, hud: true },
    player: {
      speed: clampNum(r.player?.speed, base.player.speed, 80, 900),
      jump_velocity: clampNum(r.player?.jump_velocity, base.player.jump_velocity, -900, -180),
      gravity: clampNum(r.player?.gravity, base.player.gravity, 400, 2500),
      health: clampNum(r.player?.health, base.player.health, 1, 500),
      fire_rate: clampNum(r.player?.fire_rate, base.player.fire_rate, 1, 12),
      projectile_speed: clampNum(r.player?.projectile_speed, base.player.projectile_speed, 200, 1600)
    },
    enemy: {
      count: clampInt(r.enemy?.count, base.enemy.count, 0, 20),
      speed: clampNum(r.enemy?.speed, base.enemy.speed, 20, 500),
      damage: clampInt(r.enemy?.damage, base.enemy.damage, 1, 100),
      patrol_distance: clampNum(r.enemy?.patrol_distance, base.enemy.patrol_distance, 60, 500),
      health: clampInt(r.enemy?.health, base.enemy.health, 1, 20)
    },
    level: {
      width: clampNum(r.level?.width, base.level.width, 1200, 10000),
      height: 720,
      platforms: platforms.slice(0, 12).map((p, i) => ({
        x: clampNum(p?.x, base.level.platforms[i]?.x || 500 + i * 400, 160, 9800),
        y: clampNum(p?.y, base.level.platforms[i]?.y || 450, 260, 600)
      }))
    },
    theme: {
      background: hex(r.theme?.background, base.theme.background),
      platform: hex(r.theme?.platform, base.theme.platform),
      player: hex(r.theme?.player, base.theme.player),
      enemy: hex(r.theme?.enemy, base.theme.enemy)
    },
    art: {
      palette: String(r.art?.palette || base.art.palette).slice(0, 120),
      mood: String(r.art?.mood || base.art.mood).slice(0, 120),
      visual_identity: String(r.art?.visual_identity || base.art.visual_identity).slice(0, 220),
      visual_seed: clampInt(r.art?.visual_seed, base.art.visual_seed, 1, 2147483647),
      identity: {
        ...base.art.identity,
        ...(r.art?.identity || {}),
        name: String(r.art?.identity?.name || base.art.identity.name).slice(0, 80),
        visual_description: String(r.art?.identity?.visual_description || base.art.identity.visual_description).slice(0, 240),
        outfit_colors: String(r.art?.identity?.outfit_colors || base.art.identity.outfit_colors).slice(0, 160),
        proportions: String(r.art?.identity?.proportions || base.art.identity.proportions).slice(0, 160),
        art_style: String(r.art?.identity?.art_style || style || base.art.identity.art_style).slice(0, 80),
        seed: clampInt(r.art?.identity?.seed, clampInt(r.art?.visual_seed, base.art.visual_seed, 1, 2147483647), 1, 2147483647),
        base_prompt: String(r.art?.identity?.base_prompt || base.art.identity.base_prompt).slice(0, 500),
        references: Array.isArray(r.art?.identity?.references) ? r.art.identity.references.slice(0, 4).map(x => String(x).slice(0, 300)) : [],
        character_lock: String(r.art?.identity?.character_lock || base.art.identity.character_lock || '').slice(0, 900),
        constraints: Array.isArray(r.art?.identity?.constraints) ? r.art.identity.constraints.slice(0, 12).map(x => String(x).slice(0, 180)) : (base.art.identity.constraints || [])
      },
      assets: ART_KINDS
    }
  };
}

function clampNum(value, fallback, min, max) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
function clampInt(value, fallback, min, max) {
  return Math.round(clampNum(value, fallback, min, max));
}

function gameSpecSchema() {
  return {
    type: 'object',
    properties: {
      name:{type:'string'}, description:{type:'string'}, genre:{type:'string'}, style:{type:'string'},
      game_type:{type:'string',enum:['platformer','shooter','prototype_2d']}, goal:{type:'string'},
      features:{type:'object',properties:{mobile_touch:{type:'boolean'},camera_follow:{type:'boolean'},hud:{type:'boolean'},score:{type:'boolean'},combat:{type:'boolean'},collectibles:{type:'boolean'},victory:{type:'boolean'}}},
      player:{type:'object',properties:{speed:{type:'number'},jump_velocity:{type:'number'},gravity:{type:'number'},health:{type:'number'},fire_rate:{type:'number'},projectile_speed:{type:'number'}}},
      enemy:{type:'object',properties:{count:{type:'integer'},speed:{type:'number'},damage:{type:'integer'},patrol_distance:{type:'number'},health:{type:'integer'}}},
      level:{type:'object',properties:{width:{type:'number'},height:{type:'number'},platforms:{type:'array',items:{type:'object',properties:{x:{type:'number'},y:{type:'number'}}}}}},
      theme:{type:'object',properties:{background:{type:'string'},platform:{type:'string'},player:{type:'string'},enemy:{type:'string'}}}
    },
    required:['name','description','genre','style','game_type','goal','features','player','enemy','level','theme']
  };
}

function promptForSpec(prompt, genre, style) {
  return `Você é o arquiteto do GameForge AI para Godot 4 mobile. Transforme o pedido em GAME_SPEC executável. Escolha game_type corretamente.\n\nPEDIDO: ${prompt}\nGÊNERO: ${genre}\nESTILO: ${style}\n\nREGRAS: platformer precisa de movimento lateral, pulo, plataformas, coletáveis e objetivo final. shooter precisa de movimento 2D, tiro, projéteis, dano, inimigos derrotáveis e vitória por derrotar a meta de inimigos. prototype_2d pode usar a base simples. mobile_touch=true, camera_follow=true, hud=true, score=true, victory=true. Retorne somente o objeto definido pelo schema.`;
}

async function aiSpec(env, prompt, genre, style) {
  if (!env.AI) throw new Error('Workers AI não está conectado.');
  const answer = await env.AI.run(MODEL, {
    prompt: promptForSpec(prompt, genre, style),
    response_format: { type: 'json_schema', json_schema: gameSpecSchema() },
    max_tokens: 1800,
    temperature: 0.15
  });
  return cleanJson(answer);
}

async function improveSpec(env, current, instruction) {
  if (!env.AI) throw new Error('Workers AI não está conectado.');
  const prompt = `Você é o GameForge AI. Atualize a GAME_SPEC abaixo conforme a instrução. Preserve campos e coerência de mecânicas. Se game_type=shooter, preserve tiro/projétil/combate; se platformer, preserve pulo/plataformas/coletáveis/objetivo. INSTRUÇÃO: ${instruction}\nJSON ATUAL: ${JSON.stringify(current)}`;
  const answer = await env.AI.run(MODEL, { prompt, response_format:{type:'json_schema',json_schema:gameSpecSchema()}, max_tokens:1800, temperature:0.15 });
  return cleanJson(answer);
}

async function lockVisualIdentity(env, dataUri, role = 'player') {
  if (!env.AI) throw new Error('Workers AI não está conectado.');
  const prompt = `Analise este asset de ${role === 'player' ? 'protagonista' : 'inimigo'} de um jogo 2D e crie um LOCK DE IDENTIDADE VISUAL para futuras gerações. Responda SOMENTE com JSON válido usando os campos: visual_description, outfit_colors, proportions, silhouette, materials, distinctive_features, short_prompt, constraints. Não invente informações que não possam ser percebidas na imagem. O objetivo é manter o mesmo personagem visualmente consistente.`;
  const answer = await env.AI.run(VISION_MODEL, {
    messages: [
      { role: 'system', content: 'Você é um diretor de arte de jogos 2D. Seja preciso e consistente.' },
      { role: 'user', content: prompt }
    ],
    image: dataUri,
    max_tokens: 700,
    temperature: 0.1
  });
  return cleanJson(answer);
}

function decodeDataUri(value) {
  const v = String(value || '').trim();
  const match = v.match(/^data:(image\/(?:jpeg|jpg|png))(?:;[^,]*)?;base64,([A-Za-z0-9+/=]+)$/i);
  if (!match) return null;
  try {
    const binary = atob(match[2]);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  } catch {
    return null;
  }
}

function buildArtPrompt(spec, kind) {
  const style = spec.style || 'Pixel Art';
  const palette = spec.art?.palette || 'contraste alto e leitura clara';
  const mood = spec.art?.mood || 'aventura';
  const identity = spec.art?.visual_identity || `same coherent ${style} game art identity for ${spec.name}`;
  const base = `game art, ${style}, ${mood}, palette ${palette}, ${identity}, cohesive visual language, polished indie game asset, no text, no logo`;
  const playerLock = identityLockText(spec, 'player');
  const enemyLock = identityLockText(spec, 'enemy');
  if (kind === 'player_sheet') return `${base}, ${playerLock}, horizontal 4-frame 2D game sprite sheet of the SAME playable character, four equal panels in one row, panel 1 idle, panel 2 walk pose A, panel 3 walk pose B, panel 4 jump pose, identical character design, outfit, colors and proportions in all panels, full body, centered inside each panel, clean solid magenta background #FF00FF, strong silhouette, no extra objects, no borders between panels, ${spec.description}`;
  if (kind === 'enemy_sheet') return `${base}, ${enemyLock}, horizontal 4-frame 2D game sprite sheet of the SAME enemy, four equal panels in one row, panel 1 idle, panel 2 move pose A, panel 3 move pose B, panel 4 hurt pose, identical enemy design, colors and proportions in all panels, full body, centered inside each panel, clean solid magenta background #FF00FF, strong silhouette, no extra objects, no borders between panels, ${spec.description}`;
  if (kind === 'background') return `${base}, ${playerLock}, ${enemyLock}, wide 2D game background, ${spec.description}, layered depth, gameplay-friendly composition, clear foreground and midground, no characters, no text, ${style}`;
  return `${base}, ${playerLock}, seamless-looking 2D platform surface texture, stone/ground/material suitable for platforms in this game, tile-like, no text, ${style}`;
}

function artMimeToExt(dataUri) {
  return /^data:image\/png/i.test(String(dataUri || '')) ? 'png' : 'jpg';
}

function identityLockText(spec, role = 'player') {
  const lock = String(spec.art?.identity?.character_lock || '').trim();
  const base = String(spec.art?.identity?.base_prompt || '').trim();
  const constraints = Array.isArray(spec.art?.identity?.constraints) ? spec.art.identity.constraints : [];
  const label = role === 'player' ? 'PROTAGONISTA' : 'INIMIGO';
  return [
    `LOCK DE IDENTIDADE ${label}:`,
    lock || 'a identidade visual deve permanecer estável entre gerações',
    base ? `BASE PROMPT: ${base}` : '',
    constraints.length ? `RESTRIÇÕES: ${constraints.join('; ')}` : '',
    'Não invente roupas, cores, acessórios, cabelo, silhueta ou proporções novas; mantenha os mesmos traços visuais.'
  ].filter(Boolean).join(' ');
}

function derivedSeed(spec, kind) {
  const base = Number.isInteger(spec.art?.visual_seed) ? spec.art.visual_seed : 13371337;
  let h = base >>> 0;
  for (let i = 0; i < kind.length; i++) h = Math.imul(h ^ kind.charCodeAt(i), 16777619) >>> 0;
  return h || 1;
}

function godotFiles(spec, assets = {}) {
  const assetFiles = {};
  const resources = [];
  const ids = {};
  const addAsset = (key, filename) => {
    const data = decodeDataUri(assets[key]);
    if (!data) return null;
    assetFiles[`art/${filename}`] = data;
    const id = `Art${resources.length + 1}`;
    resources.push({ id, key, filename }); ids[key] = id; return id;
  };
  addAsset('background', `background.${artMimeToExt(assets.background)}`);
  addAsset('player_sheet', `player_sheet.${artMimeToExt(assets.player_sheet)}`);
  addAsset('enemy_sheet', `enemy_sheet.${artMimeToExt(assets.enemy_sheet)}`);
  addAsset('texture', `platform_texture.${artMimeToExt(assets.texture)}`);

  const extResources = resources.map(r => `[ext_resource path="res://art/${r.filename}" type="Texture2D" id="${r.id}"]`);
  const playerVisual = ids.player_sheet
    ? `[node name="AIArt" type="Sprite2D" parent="Player"]\ntexture=ExtResource("${ids.player_sheet}")\nhframes=4\nframe=0\nscale=Vector2(0.20,0.20)\nmaterial=SubResource("PlayerChroma")\nscript=ExtResource("9")`
    : `[node name="Visual" type="Polygon2D" parent="Player"]\npolygon=PackedVector2Array(-21,-32,21,-32,21,32,-21,32)\ncolor=Color(0.37,0.85,0.80,1)`;
  const enemyVisual = (name) => ids.enemy_sheet
    ? `[node name="AIArt" type="Sprite2D" parent="${name}"]\ntexture=ExtResource("${ids.enemy_sheet}")\nhframes=4\nframe=0\nscale=Vector2(0.18,0.18)\nmaterial=SubResource("EnemyChroma")\nscript=ExtResource("10")`
    : `[node name="Visual" type="Polygon2D" parent="${name}"]\npolygon=PackedVector2Array(-21,-25,21,-25,21,25,-21,25)\ncolor=Color(0.98,0.44,0.52,1)`;
  const platformNodes = spec.level.platforms.map((p,i)=>`[node name="P${i+1}" type="StaticBody2D" parent="Platforms"]\nposition=Vector2(${p.x},${p.y})\n[node name="Collision" type="CollisionShape2D" parent="Platforms/P${i+1}"]\nshape=SubResource("PlatformShape")\n[node name="Visual" type="Polygon2D" parent="Platforms/P${i+1}"]\npolygon=PackedVector2Array(-130,-16,130,-16,130,16,-130,16)\ncolor=Color(0.31,0.44,0.57,1)`).join('\n');
  const enemyXs = [650,1050,1450,1850,2250,2650,3050,3450,3850,4250,4650,5050,5450,5850,6250,6650,7050,7450,7850,8250];
  const enemyNodes = Array.from({length:spec.enemy.count},(_,i)=>{
    const x=enemyXs[i] || 700+i*420; const y=spec.game_type==='shooter' ? 180+(i%4)*110 : 560;
    return `[node name="Enemy${i+1}" type="CharacterBody2D" parent="."]\nposition=Vector2(${x},${y})\nscript=ExtResource("3")\n[node name="Collision" type="CollisionShape2D" parent="Enemy${i+1}"]\nshape=SubResource("EnemyShape")\n${enemyVisual(`Enemy${i+1}`)}`;
  }).join('\n');
  const project=`[application]\nconfig/name="${escapeGodot(spec.name)}"\nconfig/icon="res://icon.svg"\nrun/main_scene="res://scenes/main.tscn"\n\n[display]\nwindow/size/viewport_width=1152\nwindow/size/viewport_height=648\nwindow/stretch/mode="canvas_items"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\nrenderer/rendering_method.mobile="gl_compatibility"\ntextures/default_filters/use_nearest_mipmap_filter=false\n`;
  const player=`extends CharacterBody2D\n@export var speed:float=${spec.player.speed}\n@export var jump_velocity:float=${spec.player.jump_velocity}\n@export var gravity:float=${spec.player.gravity}\n@export var max_health:int=${spec.player.health}\n@export var fire_rate:float=${spec.player.fire_rate}\n@export var projectile_speed:float=${spec.player.projectile_speed}\nvar health:int\nvar spawn_position:=Vector2.ZERO\nvar touch_x:=0.0\nvar touch_y:=0.0\nvar jump_queued:=false\nvar shoot_queued:=false\nvar shoot_timer:=0.0\nvar game_type: String = "${spec.game_type}"\nfunc _ready()->void:\n health=max_health; spawn_position=global_position\n if game_type=="shooter" and not InputMap.has_action("shoot"):\n  InputMap.add_action("shoot")\n  var key=InputEventKey.new(); key.physical_keycode=KEY_SPACE; InputMap.action_add_event("shoot",key)\nfunc _physics_process(delta:float)->void:\n shoot_timer=max(0.0,shoot_timer-delta)\n if game_type=="shooter": _shooter_move(delta)\n else: _platform_move(delta)\nfunc _platform_move(delta:float)->void:\n if not is_on_floor(): velocity.y+=gravity*delta\n var d=Input.get_axis("ui_left","ui_right")\n if abs(touch_x)>0.01: d=touch_x\n velocity.x=move_toward(velocity.x,d*speed,1800.0*delta)\n if (Input.is_action_just_pressed("ui_accept") or jump_queued) and is_on_floor(): velocity.y=jump_velocity\n jump_queued=false; move_and_slide()\n if global_position.y>950.0: respawn()\nfunc _shooter_move(delta:float)->void:\n var d=Input.get_vector("ui_left","ui_right","ui_up","ui_down")\n if abs(touch_x)>0.01 or abs(touch_y)>0.01: d=Vector2(touch_x,touch_y)\n velocity=d*speed; move_and_slide()\n global_position.x=clamp(global_position.x,32.0,${Math.max(64,spec.level.width-32)}.0); global_position.y=clamp(global_position.y,70.0,${Math.max(140,spec.level.height-100)}.0)\n if Input.is_action_pressed("shoot") or shoot_queued: shoot()\n shoot_queued=false\nfunc shoot()->void:\n if shoot_timer>0.0: return\n shoot_timer=1.0/fire_rate\n var b=preload("res://scripts/bullet.gd").new()\n b.speed=projectile_speed; b.direction=Vector2.RIGHT; b.damage=1\n get_parent().add_child(b)\n b.global_position=global_position+Vector2(34,0)\nfunc set_touch_direction(x:float,y:float)->void: touch_x=x; touch_y=y\nfunc touch_jump()->void: jump_queued=true\nfunc touch_shoot()->void: shoot_queued=true\nfunc take_damage(amount:int)->void:\n health-=amount\n if health<=0: respawn()\nfunc respawn()->void:\n global_position=spawn_position; velocity=Vector2.ZERO; health=max_health\n`;
  const enemy=`extends CharacterBody2D\n@export var speed:float=${spec.enemy.speed}\n@export var patrol_distance:float=${spec.enemy.patrol_distance}\n@export var damage:int=${spec.enemy.damage}\n@export var max_health:int=${spec.enemy.health}\nvar start_x:=0.0\nvar start_y:=0.0\nvar direction:=1.0\nvar hit_cooldown:=0.0\nvar health:int\nvar game_type:String="${spec.game_type}"\nfunc _ready()->void: start_x=global_position.x; start_y=global_position.y; health=max_health\nfunc _physics_process(delta:float)->void:\n hit_cooldown=max(0.0,hit_cooldown-delta)\n var player=get_parent().get_node_or_null("Player")\n if game_type=="shooter" and player:\n  velocity=global_position.direction_to(player.global_position)*speed; move_and_slide()\n else:\n  velocity.x=direction*speed\n  if not is_on_floor(): velocity.y+=1200.0*delta\n  move_and_slide()\n  if global_position.x>start_x+patrol_distance: direction=-1.0\n  elif global_position.x<start_x-patrol_distance: direction=1.0\n if player and hit_cooldown<=0.0 and global_position.distance_to(player.global_position)<58.0:\n  player.take_damage(damage); hit_cooldown=0.8\nfunc take_damage(amount:int)->void:\n health-=amount\n if health<=0:\n  var main=get_parent()\n  if main.has_method("register_enemy_defeated"): main.register_enemy_defeated()\n  queue_free()\n`;
  const bullet=`extends Area2D\nvar speed:float=760.0\nvar direction:=Vector2.RIGHT\nvar damage:int=1\nfunc _ready()->void:\n collision_layer=2; collision_mask=1; body_entered.connect(_on_body_entered)\n var s=Polygon2D.new(); s.polygon=PackedVector2Array(-10,-3,10,-3,10,3,-10,3); s.color=Color(1,0.9,0.2,1); add_child(s)\n var c=CollisionShape2D.new(); var sh=RectangleShape2D.new(); sh.size=Vector2(20,6); c.shape=sh; add_child(c)\nfunc _physics_process(delta:float)->void:\n position+=direction*speed*delta\n if position.x>9000.0 or position.x<0.0 or position.y<0.0 or position.y>1000.0: queue_free()\nfunc _on_body_entered(body:Node)->void:\n if body.has_method("take_damage"): body.take_damage(damage); queue_free()\n`;
  const coin=`extends Area2D\n@export var value:int=10\nfunc _ready()->void:\n body_entered.connect(_on_body_entered)\n var p=Polygon2D.new(); p.polygon=PackedVector2Array(0,-14,12,0,0,14,-12,0); p.color=Color(1,0.85,0.15,1); add_child(p)\n var c=CollisionShape2D.new(); var sh=CircleShape2D.new(); sh.radius=14; c.shape=sh; add_child(c)\nfunc _on_body_entered(body:Node)->void:\n if body.name=="Player": get_parent().register_coin(value); queue_free()\n`;
  const main=`extends Node2D\n@onready var player=$Player\n@onready var health_label=$HUD/Health\n@onready var score_label=$HUD/Score\n@onready var objective_label=$HUD/Objective\nvar score:=0\nvar defeated:=0\nvar won:=false\nfunc _ready()->void:\n health_label.text="Vida: %d"%player.health; score_label.text="Score: 0"\n objective_label.text="Derrote todos os inimigos" if "${spec.game_type}"=="shooter" else "Chegue ao portal e colete moedas"\nfunc register_coin(value:int)->void:\n score+=value; score_label.text="Score: %d"%score\nfunc register_enemy_defeated()->void:\n defeated+=1; score+=100; score_label.text="Score: %d"%score\n if "${spec.game_type}"=="shooter" and defeated>=${spec.enemy.count}: win()\nfunc _process(_delta:float)->void:\n health_label.text="Vida: %d"%player.health\n if not won and "${spec.game_type}"=="platformer" and player.global_position.x>=${Math.max(200,spec.level.width-220)}: win()\nfunc win()->void:\n if won:return\n won=true; objective_label.text="✓ VITÓRIA!"; player.set_physics_process(false)\n`;
  const touch=`extends CanvasLayer\n@onready var player=get_parent().get_node("Player")\nfunc _ready()->void:\n if "${spec.game_type}"=="shooter":\n  $Left.button_down.connect(func():player.set_touch_direction(-1,0)); $Left.button_up.connect(func():player.set_touch_direction(0,0))\n  $Right.button_down.connect(func():player.set_touch_direction(1,0)); $Right.button_up.connect(func():player.set_touch_direction(0,0))\n  $Up.button_down.connect(func():player.set_touch_direction(0,-1)); $Up.button_up.connect(func():player.set_touch_direction(0,0))\n  $Down.button_down.connect(func():player.set_touch_direction(0,1)); $Down.button_up.connect(func():player.set_touch_direction(0,0))\n  $Shoot.pressed.connect(func():player.touch_shoot())\n else:\n  $Left.button_down.connect(func():player.set_touch_direction(-1,0)); $Left.button_up.connect(func():player.set_touch_direction(0,0))\n  $Right.button_down.connect(func():player.set_touch_direction(1,0)); $Right.button_up.connect(func():player.set_touch_direction(0,0))\n  $Jump.pressed.connect(func():player.touch_jump())\n`;
  const animPlayer=`extends Sprite2D\nvar timer:=0.0\nfunc _process(delta:float)->void:\n timer+=delta; var p=get_parent()\n if p.game_type=="shooter": frame=0\n elif not p.is_on_floor(): frame=3\n elif abs(p.velocity.x)>12: frame=1+int(floor(timer*8.0))%2\n else: frame=0\n`;
  const animEnemy=`extends Sprite2D\nvar timer:=0.0\nfunc _process(delta:float)->void:\n timer+=delta; var e=get_parent(); frame=3 if e.hit_cooldown>0.0 else int(floor(timer*6.0))%3\n`;
  const chroma=`shader_type canvas_item; uniform vec4 key_color:source_color=vec4(1.0,0.0,1.0,1.0); uniform float tolerance=0.16; void fragment(){vec4 c=texture(TEXTURE,UV);if(distance(c.rgb,key_color.rgb)<tolerance)discard;COLOR=c;}`;
  const coins=spec.game_type==='platformer' ? spec.level.platforms.slice(0,Math.min(8,spec.level.platforms.length)).map((p,i)=>`[node name="Coin${i+1}" type="Area2D" parent="."]\nposition=Vector2(${p.x},${p.y-48})\nscript=ExtResource("7")`).join('\n') : '';
  const platformBlock=spec.game_type==='platformer' ? `[node name="Ground" type="StaticBody2D" parent="."]\nposition=Vector2(${Math.round(spec.level.width/2)},620)\n[node name="Collision" type="CollisionShape2D" parent="Ground"]\nshape=SubResource("GroundShape")\n[node name="Platforms" type="Node2D" parent="."]\n${platformNodes}` : '';
  const shooterWalls=spec.game_type==='shooter' ? `[node name="Walls" type="Node2D" parent="."]\n[node name="Top" type="StaticBody2D" parent="Walls"]\nposition=Vector2(${Math.round(spec.level.width/2)},45)\n[node name="Collision" type="CollisionShape2D" parent="Walls/Top"]\nshape=SubResource("WallH")\n[node name="Bottom" type="StaticBody2D" parent="Walls"]\nposition=Vector2(${Math.round(spec.level.width/2)},${spec.level.height-45})\n[node name="Collision" type="CollisionShape2D" parent="Walls/Bottom"]\nshape=SubResource("WallH")\n[node name="Left" type="StaticBody2D" parent="Walls"]\nposition=Vector2(15,${Math.round(spec.level.height/2)})\n[node name="Collision" type="CollisionShape2D" parent="Walls/Left"]\nshape=SubResource("WallV")\n[node name="Right" type="StaticBody2D" parent="Walls"]\nposition=Vector2(${spec.level.width-15},${Math.round(spec.level.height/2)})\n[node name="Collision" type="CollisionShape2D" parent="Walls/Right"]\nshape=SubResource("WallV")` : '';
  const bg=ids.background ? `[node name="AIBackground" type="Sprite2D" parent="."]\ntexture=ExtResource("${ids.background}")\nposition=Vector2(${Math.round(spec.level.width/2)},324)\nz_index=-10\nscale=Vector2(2.2,1.2)` : '';
  const touchNodes=spec.game_type==='shooter' ? `[node name="Left" type="Button" parent="TouchControls"]\noffset_left=24.0\noffset_top=520.0\noffset_right=114.0\noffset_bottom=590.0\ntext="◀"\n[node name="Right" type="Button" parent="TouchControls"]\noffset_left=124.0\noffset_top=520.0\noffset_right=214.0\noffset_bottom=590.0\ntext="▶"\n[node name="Up" type="Button" parent="TouchControls"]\noffset_left=74.0\noffset_top=450.0\noffset_right=164.0\noffset_bottom=515.0\ntext="▲"\n[node name="Down" type="Button" parent="TouchControls"]\noffset_left=74.0\noffset_top=595.0\noffset_right=164.0\noffset_bottom=645.0\ntext="▼"\n[node name="Shoot" type="Button" parent="TouchControls"]\noffset_left=980.0\noffset_top=510.0\noffset_right=1128.0\noffset_bottom=620.0\ntext="ATIRAR"` : `[node name="Left" type="Button" parent="TouchControls"]\noffset_left=24.0\noffset_top=530.0\noffset_right=124.0\noffset_bottom=620.0\ntext="◀"\n[node name="Right" type="Button" parent="TouchControls"]\noffset_left=140.0\noffset_top=530.0\noffset_right=240.0\noffset_bottom=620.0\ntext="▶"\n[node name="Jump" type="Button" parent="TouchControls"]\noffset_left=980.0\noffset_top=500.0\noffset_right=1128.0\noffset_bottom=620.0\ntext="PULAR"`;
  const scene=`[gd_scene load_steps=${16+resources.length} format=3]\n${extResources.join('\n')}\n[ext_resource path="res://scripts/main.gd" type="Script" id="1"]\n[ext_resource path="res://scripts/player.gd" type="Script" id="2"]\n[ext_resource path="res://scripts/enemy.gd" type="Script" id="3"]\n[ext_resource path="res://scripts/touch_controls.gd" type="Script" id="4"]\n[ext_resource path="res://scripts/bullet.gd" type="Script" id="5"]\n[ext_resource path="res://scripts/coin.gd" type="Script" id="6"]\n[ext_resource path="res://scripts/player_art_animation.gd" type="Script" id="9"]\n[ext_resource path="res://scripts/enemy_art_animation.gd" type="Script" id="10"]\n[sub_resource type="Shader" id="ChromaShader"]\ncode=${JSON.stringify(chroma)}\n[sub_resource type="ShaderMaterial" id="PlayerChroma"]\nshader=SubResource("ChromaShader")\n[sub_resource type="ShaderMaterial" id="EnemyChroma"]\nshader=SubResource("ChromaShader")\n[sub_resource type="RectangleShape2D" id="PlayerShape"]\nsize=Vector2(42,64)\n[sub_resource type="RectangleShape2D" id="EnemyShape"]\nsize=Vector2(42,50)\n[sub_resource type="RectangleShape2D" id="PlatformShape"]\nsize=Vector2(260,32)\n[sub_resource type="RectangleShape2D" id="GroundShape"]\nsize=Vector2(${spec.level.width},80)\n[sub_resource type="RectangleShape2D" id="WallH"]\nsize=Vector2(${spec.level.width},20)\n[sub_resource type="RectangleShape2D" id="WallV"]\nsize=Vector2(20,${spec.level.height})\n[node name="Main" type="Node2D"]\nscript=ExtResource("1")\n${bg}\n${platformBlock}\n${shooterWalls}\n[node name="Player" type="CharacterBody2D" parent="."]\nposition=Vector2(${spec.game_type==='shooter'?200:160},${spec.game_type==='shooter'?Math.round(spec.level.height/2):550})\nscript=ExtResource("2")\n[node name="Collision" type="CollisionShape2D" parent="Player"]\nshape=SubResource("PlayerShape")\n[node name="Camera2D" type="Camera2D" parent="Player"]\nposition_smoothing_enabled=true\nlimit_left=0\nlimit_right=${Math.round(spec.level.width)}\nlimit_top=0\nlimit_bottom=${Math.round(spec.level.height)}\n${playerVisual}\n${enemyNodes}\n${coins}\n[node name="HUD" type="CanvasLayer" parent="."]\n[node name="Health" type="Label" parent="HUD"]\noffset_left=24.0\noffset_top=20.0\ntext="Vida: ${spec.player.health}"\n[node name="Score" type="Label" parent="HUD"]\noffset_left=24.0\noffset_top=52.0\ntext="Score: 0"\n[node name="Objective" type="Label" parent="HUD"]\noffset_left=24.0\noffset_top=84.0\ntext="Objetivo"\n[node name="TouchControls" type="CanvasLayer" parent="."]\nscript=ExtResource("4")\n${touchNodes}`;
  const manifest={generated_at:new Date().toISOString(),version:VISUAL_VERSION,model:IMAGE_MODEL,visual_seed:spec.art?.visual_seed||null,game_type:spec.game_type,sprites:{player_sheet:{file:assets.player_sheet?`art/player_sheet.${artMimeToExt(assets.player_sheet)}`:null,frames:4},enemy_sheet:{file:assets.enemy_sheet?`art/enemy_sheet.${artMimeToExt(assets.enemy_sheet)}`:null,frames:4}},assets:Object.keys(assetFiles),identity_lock:{character_lock:spec.art?.identity?.character_lock||'',constraints:spec.art?.identity?.constraints||[]}};
  const exportPresets=`[preset.0]\nname="Android"\nplatform="Android"\nrunnable=true\ndedicated_server=false\ncustom_features=""\nexport_filter="all_resources"\ninclude_filter=""\nexclude_filter=""\nexport_path="build/GameForgeGame.apk"\nencryption_include_filters=""\nencryption_exclude_filters=""\nencrypt_pck=false\nencrypt_directory=false\n[preset.0.options]\ncustom_template/debug=""\ncustom_template/release=""\ngradle_build/use_gradle_build=false\ngradle_build/export_format=0\narchitectures/armeabi-v7a=false\narchitectures/arm64-v8a=true\narchitectures/x86=false\narchitectures/x86_64=false\nversion/code=1\nversion/name="1.0"\npackage/unique_name="ai.gameforge.generated.game"\npackage/name="${escapeGodot(spec.name)}"\npackage/signed=true\npackage/app_category=2\n`;
  return {'project.godot':project,'icon.svg':'<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><rect width="128" height="128" rx="24" fill="#16253a"/><circle cx="64" cy="64" r="40" fill="#5eead4"/></svg>','export_presets.cfg':exportPresets,'scenes/main.tscn':scene,'scripts/main.gd':main,'scripts/player.gd':player,'scripts/enemy.gd':enemy,'scripts/bullet.gd':bullet,'scripts/coin.gd':coin,'scripts/touch_controls.gd':touch,'scripts/player_art_animation.gd':animPlayer,'scripts/enemy_art_animation.gd':animEnemy,'shaders/chroma_key.gdshader':chroma,'GAME_SPEC.json':JSON.stringify(spec,null,2),'ART_MANIFEST.json':JSON.stringify(manifest,null,2),'VALIDATION.md':'GameForge 0.7 gera módulos distintos para platformer e shooter. Execute Godot --headless --editor --quit para validar importação e use o Validator do GameForge para checar mecânicas.\n',...assetFiles};
}

function validateGeneratedProject(spec, files) {
  const names = new Set(Object.keys(files)); const checks=[];
  const has=(name)=>names.has(name); const text=(name)=>String(files[name]||'');
  checks.push({id:'project',ok:has('project.godot')&&has('scenes/main.tscn')&&has('GAME_SPEC.json'),message:'estrutura Godot básica'});
  checks.push({id:'spawn',ok: spec.game_type==='platformer' ? /Ground[\s\S]*position=Vector2\([^,]+,620\)/.test(text('scenes/main.tscn')) : /node name="Walls"/.test(text('scenes/main.tscn')),message:'arena/spawn apropriados ao tipo'});
  checks.push({id:'platformer_mechanics',ok:spec.game_type!=='platformer'||(/_platform_move/.test(text('scripts/player.gd'))&&/register_coin/.test(text('scripts/main.gd'))&&/VITÓRIA/.test(text('scripts/main.gd'))),message:'mecânicas de platformer (ou não aplicável)'});
  checks.push({id:'shooter_mechanics',ok:spec.game_type!=='shooter'||(/shoot\(\)/.test(text('scripts/player.gd'))&&has('scripts/bullet.gd')&&/take_damage/.test(text('scripts/enemy.gd'))&&/register_enemy_defeated/.test(text('scripts/main.gd'))),message:'mecânicas de shooter (ou não aplicável)'});
  checks.push({id:'touch',ok:/TouchControls/.test(text('scenes/main.tscn'))&&has('scripts/touch_controls.gd'),message:'controles touch'});
  checks.push({id:'assets',ok:Object.keys(files).filter(k=>k.startsWith('art/')).length<=4,message:'assets dentro do limite'});
  return {ok:checks.every(c=>c.ok),game_type:spec.game_type,checks};
}

function escapeGodot(value) { return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }

// Minimal ZIP writer using STORE (no compression). This avoids external packages and keeps the Worker tiny.
const crcTable = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (const b of bytes) c = crcTable[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function u16(v) { return new Uint8Array([v & 255, (v >>> 8) & 255]); }
function u32(v) { return new Uint8Array([v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]); }
function concat(parts) {
  const size = parts.reduce((n, p) => n + p.length, 0); const out = new Uint8Array(size); let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; } return out;
}
function zipStore(files) {
  const enc = new TextEncoder(); const locals = []; const centrals = []; let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const nb = enc.encode(name);
    const data = content instanceof Uint8Array ? content : enc.encode(String(content));
    const crc = crc32(data);
    const local = concat([new Uint8Array([80,75,3,4]), u16(20), u16(0x800), u16(0), u16(0), u16(0), u32(crc), u32(data.length), u32(data.length), u16(nb.length), u16(0), nb, data]);
    locals.push(local);
    const central = concat([new Uint8Array([80,75,1,2]), u16(20), u16(20), u16(0x800), u16(0), u16(0), u16(0), u32(crc), u32(data.length), u32(data.length), u16(nb.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), nb]);
    centrals.push(central); offset += local.length;
  }
  const centralStart = offset;
  const body = concat(locals);
  const directory = concat(centrals);
  const end = concat([new Uint8Array([80,75,5,6]), u16(0), u16(0), u16(centrals.length), u16(centrals.length), u32(directory.length), u32(centralStart), u16(0)]);
  return concat([body, directory, end]);
}

function json(data, status = 200) { return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } }); }


async function dispatchGitHubBuild(env, projectZip, projectName) {
  if (!env.GITHUB_TOKEN || !env.GITHUB_REPO) throw new Error('Automação GitHub não configurada. Defina GITHUB_TOKEN e GITHUB_REPO no Worker.');
  const [owner, repo] = String(env.GITHUB_REPO).split('/');
  if (!owner || !repo) throw new Error('GITHUB_REPO deve ser owner/repo.');
  const path = `gameforge-builds/${slug(projectName)}-${Date.now()}.zip`;
  const b64 = bytesToBase64(projectZip);
  const headers = {'Authorization':`Bearer ${env.GITHUB_TOKEN}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json','User-Agent':'GameForge-AI'};
  const put = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`, {method:'PUT',headers,body:JSON.stringify({message:`GameForge build ${projectName}`,content:b64})});
  if (!put.ok) throw new Error(`GitHub upload falhou (${put.status}).`);
  const putData=await put.json().catch(()=>({}));
  const rawUrl=putData.content?.download_url || `https://raw.githubusercontent.com/${owner}/${repo}/main/${path}`;
  const dispatch = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/actions/workflows/build-generated-game-apk.yml/dispatches`, {method:'POST',headers,body:JSON.stringify({ref:'main',inputs:{project_url:rawUrl,project_name:slug(projectName)}})});
  if (!dispatch.ok) throw new Error(`GitHub workflow falhou (${dispatch.status}).`);
  return {path,rawUrl,workflow:'build-generated-game-apk.yml'};
}
function bytesToBase64(bytes){let s='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)s+=String.fromCharCode(...bytes.subarray(i,i+chunk));return btoa(s);}

async function handleApi(request, env) {
  const url = new URL(request.url);
  if (url.pathname === '/api/health') return json({ ok: true, service: 'GameForge AI', ai: Boolean(env.AI), text_model: MODEL, image_model: IMAGE_MODEL, vision_model: VISION_MODEL, visual_version: VISUAL_VERSION, free_tier_safe: true, github_build: Boolean(env.GITHUB_TOKEN && env.GITHUB_REPO) });

  if (request.method === 'POST' && url.pathname === '/api/test-ai') {
    if (!env.AI) return json({ ok: false, error: 'Workers AI não está conectado.' }, 503);
    try {
      const answer = await env.AI.run(MODEL, { prompt: 'Responda apenas: GAMEFORGE_OK', max_tokens: 8, temperature: 0 });
      const text = String(answer?.response || answer || '').trim();
      return json({ ok: true, connected: true, model: MODEL, response: text });
    } catch (error) {
      return json({ ok: false, connected: false, error: 'A IA da nuvem respondeu com erro. Verifique o binding AI e a cota gratuita.' }, 503);
    }
  }

  if (request.method === 'POST' && url.pathname === '/api/generate') {
    const body = await request.json().catch(() => ({}));
    const prompt = String(body.prompt || '').trim();
    const genre = String(body.genre || '2D');
    const style = String(body.style || 'Pixel Art');
    if (!prompt || prompt.length > MAX_PROMPT) return json({ error: 'Prompt vazio ou grande demais.' }, 400);
    let spec; let source = 'cloud-ai';
    try { spec = normalizeSpec(await aiSpec(env, prompt, genre, style), prompt, genre, style); }
    catch (error) { spec = defaultSpec(prompt, genre, style); source = 'fallback'; }
    return json({ ok: true, source, model: MODEL, spec, art_prompts: { player_sheet: buildArtPrompt(spec, 'player_sheet'), enemy_sheet: buildArtPrompt(spec, 'enemy_sheet'), background: buildArtPrompt(spec, 'background'), texture: buildArtPrompt(spec, 'texture') }, message: source === 'cloud-ai' ? 'Jogo planejado pela IA na nuvem. Agora você pode gerar a arte.' : 'IA indisponível no momento; foi usado o gerador local de segurança.' });
  }

  if (request.method === 'POST' && url.pathname === '/api/art') {
    const body = await request.json().catch(() => ({}));
    const kind = String(body.kind || '').trim().toLowerCase();
    const aliases = { player: 'player_sheet', enemy: 'enemy_sheet', player_sheet: 'player_sheet', enemy_sheet: 'enemy_sheet', background: 'background', texture: 'texture' };
    const normalizedKind = aliases[kind];
    if (!ART_KINDS.includes(normalizedKind)) return json({ error: 'Tipo de arte inválido.' }, 400);
    if (!env.AI) return json({ error: 'Workers AI não está conectado.' }, 503);
    const current = normalizeSpec(body.spec || {}, body.spec?.description || 'Meu jogo', body.spec?.genre || '2D', body.spec?.style || 'Pixel Art');
    const requestedPrompt = String(body.prompt || '').trim();
    const prompt = (requestedPrompt || buildArtPrompt(current, normalizedKind)).slice(0, MAX_ART_PROMPT);
    const seed = Number.isInteger(current.art?.visual_seed) ? (derivedSeed(current, normalizedKind)) : derivedSeed(current, normalizedKind);
    try {
      const result = await env.AI.run(IMAGE_MODEL, { prompt, steps: 4, seed });
      if (!result?.image) throw new Error('O modelo não devolveu imagem.');
      return json({ ok: true, kind: normalizedKind, model: IMAGE_MODEL, mime: 'image/jpeg', seed, frames: normalizedKind.endsWith('_sheet') ? 4 : 1, dataUri: `data:image/jpeg;base64,${result.image}`, prompt });
    } catch (error) {
      return json({ error: 'Não foi possível gerar a arte agora. A cota ou o modelo podem estar indisponíveis.' }, 503);
    }
  }

  if (request.method === 'POST' && url.pathname === '/api/art/lock') {
    const body = await request.json().catch(() => ({}));
    const role = body.role === 'enemy' ? 'enemy' : 'player';
    const dataUri = String(body.dataUri || '').trim();
    if (!env.AI) return json({ error: 'Workers AI não está conectado.' }, 503);
    if (!/^data:image\/(jpeg|jpg|png)(?:;[^,]*)?;base64,/i.test(dataUri)) return json({ error: 'Imagem em formato inválido.' }, 400);
    const imageBytes = decodeDataUri(dataUri);
    if (!imageBytes) return json({ error: 'Imagem Base64 inválida.' }, 400);
    if (imageBytes.byteLength > MAX_ASSET_BYTES) return json({ error: 'Imagem acima do limite.' }, 413);
    try {
      const lock = cleanJson(await lockVisualIdentity(env, dataUri, role));
      const characterLock = [
        lock.visual_description,
        lock.outfit_colors && `cores ${lock.outfit_colors}`,
        lock.proportions && `proporções ${lock.proportions}`,
        lock.silhouette && `silhueta ${lock.silhouette}`,
        lock.materials && `materiais ${lock.materials}`,
        lock.distinctive_features && `detalhes ${lock.distinctive_features}`,
        lock.short_prompt
      ].filter(Boolean).join('. ').slice(0, 900);
      return json({ ok: true, model: VISION_MODEL, role, lock: { ...lock, character_lock: characterLock } });
    } catch (error) {
      return json({ error: 'Não foi possível criar o lock visual. A cota ou o modelo de visão podem estar indisponíveis.' }, 503);
    }
  }

  if (request.method === 'POST' && url.pathname === '/api/improve') {
    const body = await request.json().catch(() => ({}));
    const instruction = String(body.instruction || '').trim();
    if (!instruction || instruction.length > MAX_INSTRUCTION) return json({ error: 'Instrução vazia ou grande demais.' }, 400);
    const current = normalizeSpec(body.current_spec || {}, body.current_spec?.description || 'Meu jogo', body.current_spec?.genre || '2D', body.current_spec?.style || 'Pixel Art');
    let spec; let source = 'cloud-ai';
    try { spec = normalizeSpec(await improveSpec(env, current, instruction), current.description, current.genre, current.style); }
    catch (error) {
      spec = structuredClone(current);
      const i = instruction.toLowerCase();
      if (/mais rápido|mais veloz|rápido/.test(i)) spec.player.speed = Math.min(900, spec.player.speed + 60);
      if (/mais lento|lento/.test(i)) spec.player.speed = Math.max(80, spec.player.speed - 60);
      if (/pulo mais alto|salto mais alto/.test(i)) spec.player.jump_velocity = Math.max(-900, spec.player.jump_velocity - 80);
      if (/mais inimigos|inimigos/.test(i)) spec.enemy.count = Math.min(12, spec.enemy.count + 2);
      source = 'fallback';
    }
    spec = normalizeSpec(spec, current.description, current.genre, current.style);
    spec.art.identity = { ...current.art.identity, ...(spec.art?.identity || {}) };
    spec.art.identity.character_lock = String(spec.art.identity.character_lock || current.art.identity.character_lock || '').slice(0, 900);
    spec.art.identity.constraints = Array.isArray(spec.art.identity.constraints) && spec.art.identity.constraints.length ? spec.art.identity.constraints : current.art.identity.constraints;
    return json({ ok: true, source, spec });
  }

  if (request.method === 'POST' && url.pathname === '/api/validate') {
    const body=await request.json().catch(()=>({}));
    const spec=normalizeSpec(body.spec||{},body.spec?.description||'Meu jogo',body.spec?.genre||'2D',body.spec?.style||'Pixel Art');
    return json({ok:true,validation:validateGeneratedProject(spec,godotFiles(spec,{}))});
  }

  if (request.method === 'POST' && url.pathname === '/api/build') {
    const body=await request.json().catch(()=>({}));
    const spec=normalizeSpec(body.spec||{},body.spec?.description||'Meu jogo',body.spec?.genre||'2D',body.spec?.style||'Pixel Art');
    const assets=body.assets&&typeof body.assets==='object'?body.assets:{};
    const files=godotFiles(spec,assets); const validation=validateGeneratedProject(spec,files);
    if(!validation.ok) return json({error:'Projeto reprovado pelo Validator.',validation},422);
    try { const zip=zipStore(files); const result=await dispatchGitHubBuild(env,zip,spec.name); return json({ok:true,validation,result,message:'Projeto enviado ao GitHub e workflow de APK disparado.'}); }
    catch(error){ return json({error:String(error.message||error)},503); }
  }

  if (request.method === 'POST' && url.pathname === '/api/export') {
    const body = await request.json().catch(() => ({}));
    const spec = normalizeSpec(body.spec || {}, body.spec?.description || 'Meu jogo', body.spec?.genre || '2D', body.spec?.style || 'Pixel Art');
    const assets = body.assets && typeof body.assets === 'object' ? body.assets : {};
    const assetKeys = Object.keys(assets).filter(key => ART_KINDS.includes(key));
    const unknownAssets = Object.keys(assets).filter(key => !ART_KINDS.includes(key));
    if (unknownAssets.length) return json({ error: `Asset(s) inválido(s): ${unknownAssets.join(', ')}.` }, 400);
    if (Object.keys(assets).length > ART_KINDS.length) return json({ error: 'Quantidade de assets acima do limite.' }, 413);
    let totalAssetBytes = 0;
    for (const key of assetKeys) {
      const value = String(assets[key] || '');
      const assetBytes = decodeDataUri(value);
      if (!assetBytes) return json({ error: `Asset ${key} está em formato Base64 inválido.` }, 400);
      if (assetBytes.byteLength > MAX_ASSET_BYTES) return json({ error: `Asset ${key} excede o limite de tamanho.` }, 413);
      totalAssetBytes += assetBytes.byteLength;
    }
    if (totalAssetBytes > MAX_TOTAL_ASSET_BYTES) return json({ error: 'O conjunto de assets excede o limite total de 16 MiB.' }, 413);
    const files = godotFiles(spec, assets);
    const validation = validateGeneratedProject(spec, files);
    if (!validation.ok) return json({ error: 'Projeto reprovado pelo Validator.', validation }, 422);
    const bytes = zipStore(files);
    const filename = `${slug(spec.name)}_godot${Object.keys(assets).length ? '_com_arte' : ''}.zip`;
    return new Response(bytes, { headers: { 'content-type': 'application/zip', 'content-disposition': `attachment; filename="${filename}"`, 'cache-control': 'no-store' } });
  }

  return json({ error: 'Rota não encontrada.' }, 404);
}

export { defaultSpec, normalizeSpec, godotFiles, validateGeneratedProject };

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) return handleApi(request, env);
    return env.ASSETS.fetch(request);
  }
};
