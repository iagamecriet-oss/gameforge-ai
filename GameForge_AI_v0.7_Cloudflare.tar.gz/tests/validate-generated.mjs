import { defaultSpec, normalizeSpec, godotFiles, validateGeneratedProject } from '../src/index.js';
const cases = [
  ['platformer', 'Crie um jogo de plataforma medieval com moedas e portal final.'],
  ['shooter', 'Crie um shooter espacial com nave, tiros, projéteis e inimigos.']
];
let failed = 0;
for (const [type, prompt] of cases) {
  const spec = normalizeSpec({ ...defaultSpec(prompt), game_type: type }, prompt, '2D', 'Pixel Art');
  const files = godotFiles(spec, {});
  const result = validateGeneratedProject(spec, files);
  console.log(`\n${type}:`, result.ok ? 'OK' : 'FAIL');
  for (const check of result.checks) console.log(` - ${check.ok ? '✓' : '✗'} ${check.message}`);
  if (!result.ok) failed++;
  if (type === 'shooter' && (!files['scripts/bullet.gd'] || !files['scripts/player.gd'].includes('shoot()'))) failed++;
  if (type === 'platformer' && !files['scripts/coin.gd']) failed++;
}
if (failed) process.exit(1);
console.log('\nValidator GameForge 0.7: PASS');
