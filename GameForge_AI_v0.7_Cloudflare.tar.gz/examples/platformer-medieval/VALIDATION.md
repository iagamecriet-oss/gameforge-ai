GameForge 0.7 gera módulos distintos para platformer e shooter. Execute Godot --headless --editor --quit para validar importação e use o Validator do GameForge para checar mecânicas.
