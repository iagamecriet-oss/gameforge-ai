extends Node2D
@onready var player=$Player
@onready var health_label=$HUD/Health
@onready var score_label=$HUD/Score
@onready var objective_label=$HUD/Objective
var score:=0
var defeated:=0
var won:=false
func _ready()->void:
 health_label.text="Vida: %d"%player.health; score_label.text="Score: 0"
 objective_label.text="Derrote todos os inimigos" if "platformer"=="shooter" else "Chegue ao portal e colete moedas"
func register_coin(value:int)->void:
 score+=value; score_label.text="Score: %d"%score
func register_enemy_defeated()->void:
 defeated+=1; score+=100; score_label.text="Score: %d"%score
 if "platformer"=="shooter" and defeated>=3: win()
func _process(_delta:float)->void:
 health_label.text="Vida: %d"%player.health
 if not won and "platformer"=="platformer" and player.global_position.x>=2980: win()
func win()->void:
 if won:return
 won=true; objective_label.text="✓ VITÓRIA!"; player.set_physics_process(false)
