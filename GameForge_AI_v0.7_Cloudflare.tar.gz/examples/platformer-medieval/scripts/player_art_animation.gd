extends Sprite2D
var timer:=0.0
func _process(delta:float)->void:
 timer+=delta; var p=get_parent()
 if p.game_type=="shooter": frame=0
 elif not p.is_on_floor(): frame=3
 elif abs(p.velocity.x)>12: frame=1+int(floor(timer*8.0))%2
 else: frame=0
