extends Sprite2D
var timer:=0.0
func _process(delta:float)->void:
 timer+=delta; var e=get_parent(); frame=3 if e.hit_cooldown>0.0 else int(floor(timer*6.0))%3
