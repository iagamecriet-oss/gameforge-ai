extends Area2D
@export var value:int=10
func _ready()->void:
 body_entered.connect(_on_body_entered)
 var p=Polygon2D.new(); p.polygon=PackedVector2Array(0,-14,12,0,0,14,-12,0); p.color=Color(1,0.85,0.15,1); add_child(p)
 var c=CollisionShape2D.new(); var sh=CircleShape2D.new(); sh.radius=14; c.shape=sh; add_child(c)
func _on_body_entered(body:Node)->void:
 if body.name=="Player": get_parent().register_coin(value); queue_free()
