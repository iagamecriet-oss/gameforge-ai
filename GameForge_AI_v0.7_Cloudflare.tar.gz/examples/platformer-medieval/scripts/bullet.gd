extends Area2D
var speed:float=760.0
var direction:=Vector2.RIGHT
var damage:int=1
func _ready()->void:
 collision_layer=2; collision_mask=1; body_entered.connect(_on_body_entered)
 var s=Polygon2D.new(); s.polygon=PackedVector2Array(-10,-3,10,-3,10,3,-10,3); s.color=Color(1,0.9,0.2,1); add_child(s)
 var c=CollisionShape2D.new(); var sh=RectangleShape2D.new(); sh.size=Vector2(20,6); c.shape=sh; add_child(c)
func _physics_process(delta:float)->void:
 position+=direction*speed*delta
 if position.x>9000.0 or position.x<0.0 or position.y<0.0 or position.y>1000.0: queue_free()
func _on_body_entered(body:Node)->void:
 if body.has_method("take_damage"): body.take_damage(damage); queue_free()
