extends CharacterBody2D
@export var speed:float=70
@export var patrol_distance:float=180
@export var damage:int=10
@export var max_health:int=2
var start_x:=0.0
var start_y:=0.0
var direction:=1.0
var hit_cooldown:=0.0
var health:int
var game_type:String="shooter"
func _ready()->void: start_x=global_position.x; start_y=global_position.y; health=max_health
func _physics_process(delta:float)->void:
 hit_cooldown=max(0.0,hit_cooldown-delta)
 var player=get_parent().get_node_or_null("Player")
 if game_type=="shooter" and player:
  velocity=global_position.direction_to(player.global_position)*speed; move_and_slide()
 else:
  velocity.x=direction*speed
  if not is_on_floor(): velocity.y+=1200.0*delta
  move_and_slide()
  if global_position.x>start_x+patrol_distance: direction=-1.0
  elif global_position.x<start_x-patrol_distance: direction=1.0
 if player and hit_cooldown<=0.0 and global_position.distance_to(player.global_position)<58.0:
  player.take_damage(damage); hit_cooldown=0.8
func take_damage(amount:int)->void:
 health-=amount
 if health<=0:
  var main=get_parent()
  if main.has_method("register_enemy_defeated"): main.register_enemy_defeated()
  queue_free()
