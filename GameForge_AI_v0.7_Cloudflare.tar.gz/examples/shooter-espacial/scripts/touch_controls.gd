extends CanvasLayer
@onready var player=get_parent().get_node("Player")
func _ready()->void:
 if "shooter"=="shooter":
  $Left.button_down.connect(func():player.set_touch_direction(-1,0)); $Left.button_up.connect(func():player.set_touch_direction(0,0))
  $Right.button_down.connect(func():player.set_touch_direction(1,0)); $Right.button_up.connect(func():player.set_touch_direction(0,0))
  $Up.button_down.connect(func():player.set_touch_direction(0,-1)); $Up.button_up.connect(func():player.set_touch_direction(0,0))
  $Down.button_down.connect(func():player.set_touch_direction(0,1)); $Down.button_up.connect(func():player.set_touch_direction(0,0))
  $Shoot.pressed.connect(func():player.touch_shoot())
 else:
  $Left.button_down.connect(func():player.set_touch_direction(-1,0)); $Left.button_up.connect(func():player.set_touch_direction(0,0))
  $Right.button_down.connect(func():player.set_touch_direction(1,0)); $Right.button_up.connect(func():player.set_touch_direction(0,0))
  $Jump.pressed.connect(func():player.touch_jump())
