extends CharacterBody2D
@export var speed:float=260
@export var jump_velocity:float=-480
@export var gravity:float=1200
@export var max_health:int=100
@export var fire_rate:float=3.5
@export var projectile_speed:float=760
var health:int
var spawn_position:=Vector2.ZERO
var touch_x:=0.0
var touch_y:=0.0
var jump_queued:=false
var shoot_queued:=false
var shoot_timer:=0.0
var game_type: String = "shooter"
func _ready()->void:
 health=max_health; spawn_position=global_position
 if game_type=="shooter" and not InputMap.has_action("shoot"):
  InputMap.add_action("shoot")
  var key=InputEventKey.new(); key.physical_keycode=KEY_SPACE; InputMap.action_add_event("shoot",key)
func _physics_process(delta:float)->void:
 shoot_timer=max(0.0,shoot_timer-delta)
 if game_type=="shooter": _shooter_move(delta)
 else: _platform_move(delta)
func _platform_move(delta:float)->void:
 if not is_on_floor(): velocity.y+=gravity*delta
 var d=Input.get_axis("ui_left","ui_right")
 if abs(touch_x)>0.01: d=touch_x
 velocity.x=move_toward(velocity.x,d*speed,1800.0*delta)
 if (Input.is_action_just_pressed("ui_accept") or jump_queued) and is_on_floor(): velocity.y=jump_velocity
 jump_queued=false; move_and_slide()
 if global_position.y>950.0: respawn()
func _shooter_move(delta:float)->void:
 var d=Input.get_vector("ui_left","ui_right","ui_up","ui_down")
 if abs(touch_x)>0.01 or abs(touch_y)>0.01: d=Vector2(touch_x,touch_y)
 velocity=d*speed; move_and_slide()
 global_position.x=clamp(global_position.x,32.0,3168.0); global_position.y=clamp(global_position.y,70.0,620.0)
 if Input.is_action_pressed("shoot") or shoot_queued: shoot()
 shoot_queued=false
func shoot()->void:
 if shoot_timer>0.0: return
 shoot_timer=1.0/fire_rate
 var b=preload("res://scripts/bullet.gd").new()
 b.global_position=global_position+Vector2(34,0); b.speed=projectile_speed; b.direction=Vector2.RIGHT; b.damage=1
 get_parent().add_child(b)
func set_touch_direction(x:float,y:float)->void: touch_x=x; touch_y=y
func touch_jump()->void: jump_queued=true
func touch_shoot()->void: shoot_queued=true
func take_damage(amount:int)->void:
 health-=amount
 if health<=0: respawn()
func respawn()->void:
 global_position=spawn_position; velocity=Vector2.ZERO; health=max_health
