# TODO — GameForge AI 0.6

- [x] IA real de texto preparada e teste `/api/test-ai`.
- [x] Geração de arte com FLUX.1 schnell.
- [x] Lock visual com modelo de visão.
- [x] `export_presets.cfg` Android no projeto Godot gerado.
- [x] Workflow para APK do próprio GameForge.
- [x] Workflow para APK de jogo Godot gerado.
- [ ] Persistência server-side.
- [ ] Autenticação.
- [ ] Filas distribuídas.
- [ ] Assinatura release/AAB.
- [ ] Identidade visual por imagem de referência/modelo dedicado.
