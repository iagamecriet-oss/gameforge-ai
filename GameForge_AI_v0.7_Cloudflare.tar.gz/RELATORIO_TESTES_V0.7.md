# GameForge AI 0.7 — relatório de validação

## Testes executados neste ambiente

- `node --check src/index.js` — OK
- `node --check public/app.js` — OK
- `npm run test:json` — OK
- `npm run test:static` — OK
- `npm run test:generated` — OK
- YAML dos workflows — OK
- `/api/health` com Worker simulado — HTTP 200
- `/api/validate` com shooter — HTTP 200 e Validator aprovado
- `/api/export` com shooter — HTTP 200 e ZIP válido
- `/api/generate` com binding AI simulado — `source=cloud-ai`

## Mecânicas 0.7

### Platformer

- movimento lateral;
- pulo e gravidade;
- chão cobrindo a largura do nível;
- plataformas;
- inimigos de patrulha;
- moedas;
- score;
- condição de vitória.

### Shooter

- movimento 2D;
- tiro;
- projéteis reais;
- colisão do projétil;
- dano e vida dos inimigos;
- inimigos perseguindo o jogador;
- score por derrota;
- vitória ao derrotar todos os inimigos;
- controles touch específicos.

## IA real

A configuração do Worker mantém o binding `AI` e agora usa `@cf/meta/llama-3.1-8b-instruct-fp8` com JSON Mode. A IA real ainda depende da publicação na conta Cloudflare do proprietário.

## Arte

A geração continua usando FLUX.1 schnell e Llama Vision. O frontend agora persiste os Data URIs das artes em IndexedDB para sobreviver ao fechamento/reabertura do PWA.

## APK automático

O endpoint `/api/build` valida o projeto, envia o ZIP ao GitHub e dispara `build-generated-game-apk.yml` quando `GITHUB_TOKEN` e `GITHUB_REPO` estão configurados.

O workflow baixa o projeto e usa os builds oficiais do Godot 4.7.2 no GitHub.

## Limitações ainda não comprovadas neste ambiente

- IA Cloudflare real: não há binding real nesta execução.
- FLUX real: não há binding real nesta execução.
- Vision real: não há binding real nesta execução.
- Execução dos jogos no Godot: o binário Godot não está instalado neste ambiente.
- Instalação do APK em dispositivo Android: não há ADB/dispositivo conectado.
- Fluxo `/api/build` real: requer token e repositório GitHub do proprietário.

Esses itens estão preparados no código, mas não devem ser marcados como testados até serem executados na conta/runner reais.
