plugins {
    id("com.android.application")
}

android {
    namespace = "ai.gameforge.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.gameforge.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.7.0"
        val workerUrl = project.findProperty("GAMEFORGE_URL")?.toString()?.trim().orEmpty()
        buildConfigField("String", "DEFAULT_WORKER_URL", "\"$workerUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
