package ai.gameforge.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "gameforge";
    private static final String WORKER_URL_KEY = "worker_url";
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private String savedUrl() {
        String stored = prefs.getString(WORKER_URL_KEY, BuildConfig.DEFAULT_WORKER_URL);
        return stored == null ? "" : stored.trim();
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 50, 40, 30);
        root.setBackgroundColor(Color.rgb(11, 16, 32));

        TextView title = new TextView(this);
        title.setText("GameForge AI");
        title.setTextSize(30f);
        title.setTextColor(Color.WHITE);

        TextView subtitle = new TextView(this);
        subtitle.setText("Cole a URL HTTPS do seu Worker Cloudflare para conectar a IA.");
        subtitle.setTextSize(16f);
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setPadding(0, 12, 0, 24);

        EditText input = new EditText(this);
        input.setHint("https://seu-worker.workers.dev");
        input.setText(savedUrl());
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setSingleLine(true);

        Button open = new Button(this);
        open.setText("Abrir GameForge AI");
        open.setOnClickListener(v -> {
            String url = normalizeUrl(input.getText().toString());
            if (url == null) {
                input.setError("Use uma URL HTTPS válida");
                return;
            }
            prefs.edit().putString(WORKER_URL_KEY, url).apply();
            showWeb(url);
        });

        Button browser = new Button(this);
        browser.setText("Abrir no Chrome");
        browser.setOnClickListener(v -> {
            String url = normalizeUrl(input.getText().toString());
            if (url == null) {
                input.setError("Use uma URL HTTPS válida");
                return;
            }
            prefs.edit().putString(WORKER_URL_KEY, url).apply();
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        });

        root.addView(title, lp());
        root.addView(subtitle, lp());
        root.addView(input, lp());
        root.addView(open, lp());
        root.addView(browser, lp());
        setContentView(root);
    }

    private void showWeb(String url) {
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl(url);
    }

    private String normalizeUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        return value.startsWith("https://") && value.length() > 12 ? value : null;
    }

    private LinearLayout.LayoutParams lp() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.bottomMargin = 18;
        return params;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            showLauncher();
        }
    }
}
