# GameForge AI 0.6

GameForge AI é uma oficina mobile-first que transforma comandos em português em projetos Godot 4 e assets visuais. A versão 0.6 mantém a base da Manus e adiciona teste de IA real, lock visual com modelo de visão, preset Android e workflows de APK em nuvem.

## Cloudflare

O Worker usa Workers AI com `@cf/meta/llama-3.2-1b-instruct` para a especificação, `@cf/black-forest-labs/flux-1-schnell` para imagens e `@cf/meta/llama-3.2-11b-vision-instruct` para lock visual. Os nomes de modelos estão de acordo com a documentação atual da Cloudflare.

## Android sem computador

1. Envie o projeto para o GitHub.
2. No Cloudflare, publique o Worker com o binding `AI`.
3. No GitHub, execute `Build GameForge AI APK` para compilar o app Android.
4. No app, informe a URL `https://...workers.dev` do Worker.

## Limites honestos

A IA real só é comprovada depois que o Worker é publicado com `AI` ativo. A arte depende da cota e do modelo. A identidade visual é reforçada por lock textual, mas não é matematicamente garantida. O APK debug é instalável para testes; assinatura release é outra etapa.

## Referências técnicas verificadas em 04/10/2026

- Cloudflare Workers AI: https://developers.cloudflare.com/workers-ai/
- Modelo Llama 3.2 1B: https://developers.cloudflare.com/workers-ai/models/llama-3.2-1b-instruct/
- Modelo FLUX.1 schnell: https://developers.cloudflare.com/workers-ai/models/flux-1-schnell/
- Tutorial Llama Vision: https://developers.cloudflare.com/workers-ai/guides/tutorials/llama-vision-tutorial/
- Godot Android export: https://docs.godotengine.org/en/latest/tutorials/export/exporting_for_android.html

## v0.7 — evolução

- Platformer e shooter agora usam runtimes diferentes.
- Validator automático antes do ZIP/APK.
- JSON Mode para GAME_SPEC com modelo compatível.
- Arte persistida no Android via IndexedDB.
- `/api/build` envia o projeto ao GitHub e dispara o workflow de APK quando `GITHUB_TOKEN` e `GITHUB_REPO` estão configurados.
- Workflow Android usa builds oficiais do Godot.

Veja `docs/SETUP_IA_REAL_E_APK_AUTOMATICO.md` e `docs/MECANICAS_MODULARES_V0.7.md`.
