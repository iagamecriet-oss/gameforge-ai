# Instruções para a Manus — GameForge AI 0.6

Esta versão já corrige uma parte dos pontos pendentes do relatório anterior. Não recomece o projeto do zero.

## O que já foi corrigido

1. Teste explícito do binding AI em `/api/test-ai`.
2. Modelo de visão para criar lock textual de identidade em `/api/art/lock`.
3. Prompt visual reutiliza o lock de personagem/inimigo.
4. `GAME_SPEC.json` guarda identidade e restrições.
5. `export_presets.cfg` Android é incluído nos projetos Godot exportados.
6. Workflow `.github/workflows/build-gameforge-apk.yml` cria APK debug instalável do próprio GameForge.
7. Workflow `.github/workflows/build-generated-game-apk.yml` recebe `gameforge-input.zip` e gera APK do jogo criado.
8. Wrapper Android usa Java puro, sem dependência do Kotlin plugin.

## Sua tarefa agora

Analise e teste a versão 0.6. Prioridade máxima:

- publicar/testar o Worker com binding AI real;
- testar `/api/test-ai`;
- testar `/api/generate`;
- gerar `player_sheet` e `enemy_sheet`;
- testar `/api/art/lock`;
- confirmar que o lock aparece no GAME_SPEC;
- testar `/api/export` com arte;
- executar `Build GameForge AI APK` em GitHub Actions;
- executar `Build generated Godot game APK`;
- instalar o APK debug em um Android e registrar o resultado;
- não declarar nenhum teste como OK sem executar de verdade.

## Não fazer

Não adicionar API paga como fallback silencioso. Não colocar chaves secretas no frontend. Não remover os workflows existentes sem substituição equivalente.
