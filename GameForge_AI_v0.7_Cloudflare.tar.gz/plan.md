# Plano de evolução — GameForge AI

## Direção
Evoluir o PWA/Worker existente, preservando as rotas `/api/generate`, `/api/art`, `/api/improve`, `/api/export` e `/api/health`. A experiência continua mobile-first e sem serviços pagos adicionados automaticamente.

## Estrutura atual e responsabilidades
- `public/index.html`: shell PWA, criação, melhoria, projetos e laboratório visual.
- `public/app.js`: estado da sessão, persistência local, chamadas ao Worker, progresso e exportação.
- `public/style.css`: linguagem visual escura, responsiva e confortável para toque.
- `src/index.js`: Worker Cloudflare, normalização de GAME_SPEC, IA textual/visual, gerador Godot e ZIP STORE.
- `public/manus-routes.json`: manifesto de rotas de página para a infraestrutura WebDev.
- `docs/`: arquitetura, pipeline visual, build Android e relatório de validação.

## Implementação
1. Fortalecer o modelo de projeto com `project_id`, `revision`, `history`, identidade visual e metadados de geração.
2. Tornar melhorias incrementais explícitas: preservar histórico, permitir desfazer/reaplicar e invalidar somente os assets quando a identidade visual mudar.
3. Melhorar a UI mobile com estados de tarefa, cancelamento via `AbortController`, mensagens de cota/erro e carregamento de projetos salvos.
4. Tornar o export Godot mais verificável e documentar o workflow cloud de APK sem alegar uma compilação que não foi executada.
5. Validar sintaxe JS, JSON, Worker, ZIP exportado e projeto Godot com `godot --headless --editor --quit` quando disponível.

## Design
- **Movimento:** cockpit editorial de ferramenta criativa, com contraste entre azul elétrico e verde-lima.
- **Princípios:** foco na ação principal, estados sempre visíveis, densidade controlada e toque sem precisão excessiva.
- **Cores:** fundo azul-noite para longas sessões; azul para criação; verde para sucesso e identidade; âmbar para cotas.
- **Layout:** fluxo vertical de oficina, com navegação inferior e cartões de trabalho, evitando painéis desktop comprimidos.
- **Assinaturas:** marcador de versão, pílula de estado e barra de progresso segmentada.
- **Interação/animação:** transições curtas, feedback imediato, nenhum loop silencioso; tarefas longas podem ser canceladas.
- **Tipografia:** system-ui para legibilidade e hierarquia por peso/tamanho, sem depender de fontes externas.
- **Essência:** uma oficina de jogos Godot que transforma linguagem natural em um projeto editável, pelo celular; clara, criativa, econômica.
- **Voz:** direta e encorajadora. Exemplos: “Descreva a próxima versão do seu jogo.” / “A arte ficou pronta para entrar no ZIP.”
- **Marca:** wordmark GameForge com pequeno símbolo de forja/controle no ícone já existente.
- **Cor proprietária:** azul-violeta `#6d8cff`, usado apenas em ações primárias.
