# GameForge AI 0.6 — resumo para próxima revisão da Manus

Esta é a versão corrigida pelo projeto após a primeira entrega da Manus.

### Implementado
- teste explícito da IA em `/api/test-ai`;
- lock visual em `/api/art/lock` usando Llama 3.2 11B Vision;
- prompts reutilizam o lock para personagem/inimigo;
- `character_lock` e restrições entram no `GAME_SPEC`;
- preset Android é incluído nos ZIPs Godot;
- workflow de APK do próprio GameForge;
- workflow de APK de jogos gerados usando `gameforge-input.zip`;
- wrapper Android em Java puro;
- documentação de fluxo Android sem PC.

### Resultado da validação local
- JavaScript: OK
- JSON: OK
- YAML: OK
- rotas Worker com IA simulada: OK
- exportação ZIP: OK
- `export_presets.cfg` dentro do ZIP: OK

### Ainda precisa ser comprovado no ambiente da Manus/Cloudflare/GitHub
- binding `AI` real do Worker;
- geração real com Llama/FLUX/Vision;
- compilação real do APK pelo GitHub Actions;
- instalação e abertura do APK em Android;
- teste real de exportação de um jogo gerado para APK.

Não declarar essas etapas como concluídas antes de executá-las.
